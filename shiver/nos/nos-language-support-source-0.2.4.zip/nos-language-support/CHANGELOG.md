## [0.2.4] - 2026-11-06
- Brightened regular NOS command decorations to green (#89D185) for better contrast on dark themes.
- Added purple (#C586C0) decorations for commands under the `# Op module commands` section in the live syntax.txt.
- Added module-section metadata to parsed command signatures; color classification updates automatically when syntax.txt changes.

# Change Log

## [0.2.3] - 2026-11-06
- Replaced theme-dependent semantic token coloring with explicit TextEditor decorations.
- NOS command names are green (#6A9955); labels are yellow (#DCDCAA).
- Highlight scanner respects multiline single-quoted strings and comments.

# Change Log

## [0.2.2] - 2026-11-06

- Added yellow semantic highlighting for jump labels such as `@propPlace`.
- Updated semantic highlighting to use standard VS Code `function` and `label` token types for more reliable theme coloring.
- Fixed green highlighting for module commands such as `Shiver.music`, `Entity.tp`, `World.time`, and `Player.message`, using the live `syntax.txt` command catalogue.

## [0.2.1]

- Treat `var(...)` and `global(...)` contents as opaque variable paths inside math expressions.
- Restore green highlighting for command names.
