'use strict';

const vscode = require('vscode');
const path = require('node:path');
const https = require('node:https');
const { parseSyntaxDefinitions, validateDocument } = require('./syntax');
const { collectHighlights } = require('./highlight');

const DEFAULT_SYNTAX_URL = 'https://raw.githubusercontent.com/MentasChanneL/mentaschannel.github.io/main/shiver/scripts/syntax.txt';
let definitions = new Map();
let syntaxSource = 'bundled syntax.txt';
let diagnosticCollection;
let statusBar;
let contextRef;
let debounceTimers = new Map();
let scriptPaths = [];
let scriptIndexPromise = null;
let commandDecoration;
let opCommandDecoration;
let labelDecoration;

function isNosDocument(document) {
  return document.languageId === 'nos' || document.fileName.toLowerCase().endsWith('.nos');
}

function asDiagnostic(item) {
  const range = new vscode.Range(
    new vscode.Position(item.range.start.line, item.range.start.character),
    new vscode.Position(item.range.end.line, item.range.end.character)
  );
  const diagnostic = new vscode.Diagnostic(range, item.message, vscode.DiagnosticSeverity.Error);
  diagnostic.source = 'NOS';
  diagnostic.code = item.code;
  return diagnostic;
}

function allDefinitions() {
  // The current syntax.txt is the sole command catalogue. No old command list
  // is merged in, so removed or renamed commands disappear automatically.
  return definitions;
}

function signatureText(definition) {
  return `${definition.name} ${definition.params.map(p => `${p.type}(${p.name})`).join(' ')}`.trim();
}

function refreshStatusBar() {
  if (!statusBar) return;
  statusBar.text = `$(symbol-keyword) NOS · ${definitions.size} commands`;
  statusBar.tooltip = `Command signatures parsed from: ${syntaxSource}\nClick to reload syntax.txt`;
  statusBar.show();
}

async function readUriText(uri) {
  const bytes = await vscode.workspace.fs.readFile(uri);
  return Buffer.from(bytes).toString('utf8');
}

function configuredSyntaxUri(configuredPath) {
  if (!configuredPath) return null;
  const folders = vscode.workspace.workspaceFolders || [];
  const expanded = configuredPath.replace(/\$\{workspaceFolder\}/g, folders[0]?.uri.fsPath || '');
  if (path.isAbsolute(expanded)) return vscode.Uri.file(expanded);
  if (!folders.length) return vscode.Uri.file(path.resolve(expanded));
  return vscode.Uri.joinPath(folders[0].uri, expanded.replace(/\\/g, '/'));
}

async function findWorkspaceSyntax() {
  const config = vscode.workspace.getConfiguration('nos');
  const configuredPath = config.get('syntaxFile', '').trim();
  if (configuredPath) {
    const uri = configuredSyntaxUri(configuredPath);
    try {
      return { text: await readUriText(uri), source: uri.fsPath || uri.toString() };
    } catch (error) {
      vscode.window.showWarningMessage(`NOS: cannot read configured syntax file: ${error.message}`);
    }
  }

  if (!vscode.workspace.workspaceFolders?.length) return null;
  const files = await vscode.workspace.findFiles('**/syntax.txt', '**/{.git,node_modules}/**', 100);
  if (!files.length) return null;

  const priority = uri => {
    const p = (uri.path || '').toLowerCase();
    if (p.endsWith('/shiver/scripts/syntax.txt')) return 0;
    if (p.endsWith('/scripts/syntax.txt')) return 1;
    return 2;
  };
  files.sort((a, b) => priority(a) - priority(b) || a.path.localeCompare(b.path));
  const uri = files[0];
  return { text: await readUriText(uri), source: uri.fsPath || uri.toString() };
}

async function loadSyntax() {
  let loaded = await findWorkspaceSyntax();
  if (!loaded) {
    const cachedUri = vscode.Uri.joinPath(contextRef.globalStorageUri, 'syntax.txt');
    try {
      loaded = { text: await readUriText(cachedUri), source: 'GitHub syntax.txt cache' };
    } catch (_) {
      // Fall back to the checked-in snapshot included in the extension.
    }
  }
  if (!loaded) {
    const bundledUri = vscode.Uri.file(path.join(contextRef.extensionPath, 'syntax.txt'));
    try {
      loaded = { text: await readUriText(bundledUri), source: 'bundled syntax.txt snapshot' };
    } catch (error) {
      loaded = { text: '', source: `no syntax.txt found (${error.message})` };
    }
  }

  const nextDefinitions = parseSyntaxDefinitions(loaded.text);
  if (loaded.text.trim() && nextDefinitions.size === 0) {
    vscode.window.showWarningMessage('NOS: syntax.txt was found, but no command signatures could be parsed. Keeping the previous command catalogue.');
    return;
  }
  definitions = nextDefinitions;
  syntaxSource = loaded.source;
  refreshStatusBar();
  validateOpenDocuments();
  refreshVisibleEditorHighlights();
}

function validateDocumentNow(document) {
  if (!isNosDocument(document) || !diagnosticCollection) return;
  const items = validateDocument(document.getText(), allDefinitions());
  diagnosticCollection.set(document.uri, items.map(asDiagnostic));
}

function scheduleValidation(document) {
  const config = vscode.workspace.getConfiguration('nos');
  if (!config.get('validateOnType', true)) return;
  const key = document.uri.toString();
  const oldTimer = debounceTimers.get(key);
  if (oldTimer) clearTimeout(oldTimer);
  const timer = setTimeout(() => {
    debounceTimers.delete(key);
    validateDocumentNow(document);
  }, 160);
  debounceTimers.set(key, timer);
}

function validateOpenDocuments() {
  for (const document of vscode.workspace.textDocuments) validateDocumentNow(document);
}

function downloadText(url, redirects = 4) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, { headers: { 'User-Agent': 'NOS-VSCode-Extension' } }, response => {
      const status = response.statusCode || 0;
      if ([301, 302, 303, 307, 308].includes(status) && response.headers.location && redirects > 0) {
        response.resume();
        resolve(downloadText(new URL(response.headers.location, url).toString(), redirects - 1));
        return;
      }
      if (status !== 200) {
        response.resume();
        reject(new Error(`HTTP ${status}`));
        return;
      }
      const chunks = [];
      response.on('data', chunk => chunks.push(chunk));
      response.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      response.on('error', reject);
    });
    request.setTimeout(12000, () => request.destroy(new Error('Request timed out')));
    request.on('error', reject);
  });
}

async function updateSyntaxFromGitHub() {
  const config = vscode.workspace.getConfiguration('nos');
  const url = config.get('syntaxUrl', DEFAULT_SYNTAX_URL).trim();
  try {
    const content = await downloadText(url);
    if (!content.trim() || parseSyntaxDefinitions(content).size === 0) throw new Error('Downloaded syntax.txt contains no command signatures');
    const folder = vscode.workspace.workspaceFolders?.[0];
    const suggested = folder
      ? vscode.Uri.joinPath(folder.uri, 'shiver', 'scripts', 'syntax.txt')
      : vscode.Uri.joinPath(contextRef.globalStorageUri, 'syntax.txt');
    const target = await vscode.window.showSaveDialog({
      defaultUri: suggested,
      saveLabel: 'Save syntax.txt',
      filters: { 'NOS syntax file': ['txt'] }
    });
    if (!target) return;
    await vscode.workspace.fs.createDirectory(target.with({ path: path.posix.dirname(target.path) }));
    await vscode.workspace.fs.writeFile(target, Buffer.from(content, 'utf8'));
    const targetPath = target.fsPath || target.path;
    await vscode.workspace.getConfiguration('nos').update('syntaxFile', targetPath, vscode.ConfigurationTarget.Workspace);
    vscode.window.showInformationMessage(`NOS: syntax.txt saved and selected: ${target.fsPath || target.toString()}`);
    await loadSyntax();
  } catch (error) {
    vscode.window.showErrorMessage(`NOS: failed to download syntax.txt: ${error.message}`);
  }
}

async function selectSyntaxFile() {
  const selected = await vscode.window.showOpenDialog({
    canSelectFiles: true,
    canSelectFolders: false,
    canSelectMany: false,
    openLabel: 'Use syntax.txt',
    filters: { 'NOS syntax file': ['txt'] }
  });
  if (!selected?.length) return;
  await vscode.workspace.getConfiguration('nos').update('syntaxFile', selected[0].fsPath, vscode.ConfigurationTarget.Workspace);
  await loadSyntax();
}

function scriptPathFromUri(uri) {
  const segments = uri.path.split('/').filter(Boolean);
  const scriptsIndex = segments.lastIndexOf('scripts');
  let relative;
  if (scriptsIndex !== -1 && scriptsIndex < segments.length - 1) {
    relative = segments.slice(scriptsIndex + 1).join('/');
  } else {
    const folder = vscode.workspace.getWorkspaceFolder(uri);
    if (!folder) return null;
    relative = path.posix.relative(folder.uri.path, uri.path);
  }
  if (!relative.toLowerCase().endsWith('.nos')) return null;
  return relative.slice(0, -4).replace(/^\.\//, '');
}

async function refreshScriptIndex() {
  if (scriptIndexPromise) return scriptIndexPromise;
  scriptIndexPromise = (async () => {
    if (!vscode.workspace.workspaceFolders?.length) {
      scriptPaths = [];
      return scriptPaths;
    }
    const files = await vscode.workspace.findFiles('**/*.nos', '**/{.git,node_modules,.vscode}/**', 3000);
    const paths = new Set();
    for (const uri of files) {
      const item = scriptPathFromUri(uri);
      if (item && !item.startsWith('../') && !item.startsWith('.')) paths.add(item);
    }
    scriptPaths = [...paths].sort((a, b) => a.localeCompare(b));
    return scriptPaths;
  })().finally(() => { scriptIndexPromise = null; });
  return scriptIndexPromise;
}

function scriptPathCompletions(document, position) {
  const line = document.lineAt(position.line).text;
  const beforeCursor = line.slice(0, position.character);
  const match = beforeCursor.match(/^\s*([A-Za-z_][A-Za-z0-9_.]*)\s+'([^']*)$/);
  if (!match) return null;
  const definition = definitions.get(match[1]);
  const firstParam = definition?.params?.[0];
  if (!firstParam || firstParam.type !== 'text' || !/script path/i.test(firstParam.name)) return null;

  const typedPath = match[2];
  const valueStart = beforeCursor.lastIndexOf("'") + 1;
  const range = new vscode.Range(position.line, valueStart, position.line, position.character);
  return refreshScriptIndex().then(paths => {
    const list = new vscode.CompletionList([], true);
    for (const item of paths) {
      if (typedPath && !item.toLowerCase().startsWith(typedPath.toLowerCase())) continue;
      const completion = new vscode.CompletionItem(item, vscode.CompletionItemKind.File);
      completion.insertText = item;
      completion.range = range;
      completion.detail = `${item}.nos`;
      completion.sortText = `0_${item}`;
      list.items.push(completion);
    }
    return list;
  });
}

function commandCompletion(document, position) {
  const line = document.lineAt(position.line).text;
  const before = line.slice(0, position.character);
  const match = before.match(/^\s*([A-Za-z_][A-Za-z0-9_.]*)?$/);
  if (!match) return null;
  const prefix = match[1] || '';
  const items = [];
  for (const definition of allDefinitions().values()) {
    if (prefix && !definition.name.toLowerCase().startsWith(prefix.toLowerCase())) continue;
    const item = new vscode.CompletionItem(definition.name, vscode.CompletionItemKind.Function);
    item.detail = signatureText(definition);
    item.documentation = new vscode.MarkdownString('Сигнатура загружена из текущего `syntax.txt`.');
    const placeholders = definition.params.map((param, index) => {
      const n = index + 1;
      const tabstop = (defaultValue = '') => '${' + n + (defaultValue ? ':' + defaultValue : '') + '}';
      if (param.type === 'text') return "'" + tabstop(param.name || 'text') + "'";
      if (param.type === 'math') return tabstop('0') + ';';
      if (param.type === 'list') return '[' + tabstop() + ']';
      if (param.type === 'block') return '{\n\t' + tabstop() + '\n}';
      return tabstop('value');
    });
    const insert = placeholders.length ? `${definition.name} ${placeholders.join(' ')}` : definition.name;
    item.insertText = new vscode.SnippetString(insert);
    item.sortText = `0_${definition.name}`;
    items.push(item);
  }
  return new vscode.CompletionList(items, true);
}

function createCompletionProvider() {
  return {
    provideCompletionItems(document, position) {
      const pathItems = scriptPathCompletions(document, position);
      if (pathItems) return pathItems;
      return commandCompletion(document, position);
    }
  };
}

function createHoverProvider() {
  return {
    provideHover(document, position) {
      const line = document.lineAt(position.line).text;
      const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_.]*)/);
      if (!match) return null;
      const name = match[1];
      const start = line.indexOf(name);
      if (position.character < start || position.character > start + name.length) return null;
      const definition = definitions.get(name);
      if (!definition) return null;
      const markdown = new vscode.MarkdownString();
      markdown.appendCodeblock(signatureText(definition), 'nos');
      markdown.appendMarkdown('\n\n');
      if (definition.params[0]?.type === 'text' && /script path/i.test(definition.params[0].name)) {
        markdown.appendMarkdown('Путь скрипта подсказывается по `.nos`-файлам в папке `scripts/`. В вызовах NOS расширение `.nos` обычно не указывается.');
      }
      if (definition.params.at(-1)?.type === 'block') {
        markdown.appendMarkdown('Последний аргумент — блок кода в `{ ... }`.');
      }
      return new vscode.Hover(markdown, new vscode.Range(position.line, start, position.line, start + name.length));
    }
  };
}

function refreshEditorHighlights(editor) {
  if (!commandDecoration || !opCommandDecoration || !labelDecoration || !editor) return;
  if (!isNosDocument(editor.document)) {
    editor.setDecorations(commandDecoration, []);
    editor.setDecorations(opCommandDecoration, []);
    editor.setDecorations(labelDecoration, []);
    return;
  }

  const commandRanges = [];
  const opCommandRanges = [];
  const labelRanges = [];
  for (const span of collectHighlights(editor.document.getText(), allDefinitions())) {
    const range = new vscode.Range(
      new vscode.Position(span.line, span.start),
      new vscode.Position(span.line, span.start + span.length)
    );
    if (span.type === 'label') labelRanges.push(range);
    else if (span.type === 'opCommand') opCommandRanges.push(range);
    else commandRanges.push(range);
  }
  editor.setDecorations(commandDecoration, commandRanges);
  editor.setDecorations(opCommandDecoration, opCommandRanges);
  editor.setDecorations(labelDecoration, labelRanges);
}

function refreshVisibleEditorHighlights() {
  for (const editor of vscode.window.visibleTextEditors) refreshEditorHighlights(editor);
}

function activate(context) {
  contextRef = context;
  diagnosticCollection = vscode.languages.createDiagnosticCollection('nos');
  statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 80);
  statusBar.command = 'nos.reloadSyntax';
  context.subscriptions.push(diagnosticCollection, statusBar);

  // Explicit editor decorations enforce the requested NOS colors regardless
  // of the active VS Code theme or its semantic-token color rules.
  // Brighter green remains readable on common dark themes. Commands in the
  // Op module section of syntax.txt get a distinct purple decoration.
  commandDecoration = vscode.window.createTextEditorDecorationType({ color: '#89D185' });
  opCommandDecoration = vscode.window.createTextEditorDecorationType({ color: '#C586C0' });
  labelDecoration = vscode.window.createTextEditorDecorationType({ color: '#DCDCAA' });
  context.subscriptions.push(commandDecoration, opCommandDecoration, labelDecoration);
  const completionProvider = createCompletionProvider();
  const hoverProvider = createHoverProvider();

  context.subscriptions.push(
    vscode.commands.registerCommand('nos.reloadSyntax', loadSyntax),
    vscode.commands.registerCommand('nos.selectSyntaxFile', selectSyntaxFile),
    vscode.commands.registerCommand('nos.updateSyntaxFromGitHub', updateSyntaxFromGitHub),
    vscode.languages.registerCompletionItemProvider({ language: 'nos' }, completionProvider, "'", '/', '.'),
    vscode.languages.registerHoverProvider({ language: 'nos' }, hoverProvider),
    vscode.workspace.onDidOpenTextDocument(document => { validateDocumentNow(document); refreshVisibleEditorHighlights(); }),
    vscode.workspace.onDidChangeTextDocument(event => { scheduleValidation(event.document); refreshVisibleEditorHighlights(); }),
    vscode.window.onDidChangeActiveTextEditor(editor => refreshEditorHighlights(editor)),
    vscode.window.onDidChangeVisibleTextEditors(() => refreshVisibleEditorHighlights()),
    vscode.workspace.onDidSaveTextDocument(validateDocumentNow),
    vscode.workspace.onDidCloseTextDocument(document => diagnosticCollection.delete(document.uri)),
    vscode.workspace.onDidChangeConfiguration(event => {
      if (event.affectsConfiguration('nos')) loadSyntax();
    }),
    vscode.workspace.onDidChangeWorkspaceFolders(() => { scriptPaths = []; refreshScriptIndex(); loadSyntax(); })
  );

  const syntaxWatcher = vscode.workspace.createFileSystemWatcher('**/syntax.txt');
  syntaxWatcher.onDidCreate(loadSyntax);
  syntaxWatcher.onDidChange(loadSyntax);
  syntaxWatcher.onDidDelete(loadSyntax);
  context.subscriptions.push(syntaxWatcher);

  const scriptWatcher = vscode.workspace.createFileSystemWatcher('**/*.nos');
  scriptWatcher.onDidCreate(() => { scriptPaths = []; refreshScriptIndex(); });
  scriptWatcher.onDidDelete(() => { scriptPaths = []; refreshScriptIndex(); });
  scriptWatcher.onDidChange(() => { /* paths are unchanged */ });
  context.subscriptions.push(scriptWatcher);

  loadSyntax();
  refreshScriptIndex();
  for (const document of vscode.workspace.textDocuments) validateDocumentNow(document);
  refreshVisibleEditorHighlights();
}

function deactivate() {
  for (const timer of debounceTimers.values()) clearTimeout(timer);
  debounceTimers.clear();
}

module.exports = { activate, deactivate };
