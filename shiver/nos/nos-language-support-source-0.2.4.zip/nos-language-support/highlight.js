
'use strict';

const BUILTIN_COMMANDS = new Set([
  'if', 'else', 'set', 'setGlobal', 'wait', 'jump', 'print',
  'signal', 'actionbar', 'pass', 'return'
]);

/**
 * Collects ranges for the command/label decorations.
 * NOS strings may span lines, so command-looking text inside a continued
 * single-quoted string must not be highlighted as a command.
 */
function collectHighlights(text, commandDefinitions) {
  const spans = [];
  const lines = text.split(/\n/);
  let insideString = false;

  for (let line = 0; line < lines.length; line++) {
    const source = lines[line].replace(/\r$/, '');
    let i = 0;

    // A continued string from the previous line owns this entire line until
    // its closing single quote. There is no escape syntax in NOS strings.
    if (!insideString) {
      while (i < source.length && (source[i] === ' ' || source[i] === '\t')) i++;

      if (i < source.length && source[i] !== '#') {
        if (source[i] === '@') {
          const match = source.slice(i).match(/^@[A-Za-z_][A-Za-z0-9_.-]*/);
          if (match) spans.push({ line, start: i, length: match[0].length, type: 'label' });
        } else {
          const match = source.slice(i).match(/^([A-Za-z_][A-Za-z0-9_.]*)\b/);
          if (match) {
            const name = match[1];
            const definition = commandDefinitions.get(name);
            if (definition || BUILTIN_COMMANDS.has(name)) {
              spans.push({
                line,
                start: i,
                length: name.length,
                type: definition?.module === 'op' ? 'opCommand' : 'command'
              });
            }
          }
        }
      }
    }

    // Track string state to correctly handle multiline NOS strings and
    // comments. A # inside a string is ordinary text; outside, it ends line.
    for (; i < source.length; i++) {
      const ch = source[i];
      if (ch === "'") {
        insideString = !insideString;
        continue;
      }
      if (ch === '#' && !insideString) break;
    }
  }

  return spans;
}

module.exports = { BUILTIN_COMMANDS, collectHighlights };
