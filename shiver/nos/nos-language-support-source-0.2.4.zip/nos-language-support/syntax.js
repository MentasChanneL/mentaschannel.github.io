'use strict';

const PARAM_TYPES = new Set(['text', 'math', 'list', 'block', 'any']);
const PARAM_DECLARATION = /\b(text|math|list|block|any)\s*\(([^)]*)\)/gi;

function parseParamDeclarations(source) {
  const params = [];
  PARAM_DECLARATION.lastIndex = 0;
  let match;
  while ((match = PARAM_DECLARATION.exec(source)) !== null) {
    params.push({ type: match[1].toLowerCase(), name: match[2].trim() });
  }
  return params;
}


function tokenizeMathExpression(source) {
  const tokens = [];
  let i = 0;
  let expectsOperand = true;
  const push = (type, value, start, end) => {
    tokens.push({ type, value, start, end });
    if (type === 'number' || type === 'identifier' || type === 'expansion' || type === ')') expectsOperand = false;
    else if (type === '(' || type === ',' || type === ':' || type === 'operator') expectsOperand = true;
  };

  while (i < source.length) {
    const ch = source[i];
    if (/\s/.test(ch)) { i++; continue; }
    const start = i;

    if (ch === "'") return { tokens, error: { message: 'Text strings cannot be used as math expressions', start: i } };
    if (ch === '"') return { tokens, error: { message: 'Double-quoted strings are not supported in NOS', start: i } };

    if (ch === '*' && expectsOperand && /[A-Za-z_]/.test(source[i + 1] || '')) {
      i += 2;
      while (i < source.length && /[A-Za-z0-9_.$]/.test(source[i])) i++;
      push('expansion', source.slice(start, i), start, i);
      continue;
    }

    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(source[i + 1] || ''))) {
      const match = source.slice(i).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/);
      i += match[0].length;
      push('number', match[0], start, i);
      continue;
    }

    if (/[A-Za-z_$]/.test(ch)) {
      i++;
      while (i < source.length && /[A-Za-z0-9_$]/.test(source[i])) i++;
      const identifier = source.slice(start, i);

      // NOS variable references are not ordinary math function calls. Their
      // contents are opaque text (for example var(arg.1), global(MAP), or
      // global(var(target).ifFalled)), so do not parse the inside as math.
      if ((identifier === 'var' || identifier === 'global') && source[i] === '(') {
        let depth = 0;
        do {
          const current = source[i];
          if (current === '(') depth++;
          else if (current === ')') depth--;
          i++;
        } while (i < source.length && depth > 0);
        if (depth !== 0) {
          return { tokens, error: { message: `Unclosed ${identifier}() variable reference`, start } };
        }
        push('reference', source.slice(start, i), start, i);
      } else {
        push('identifier', identifier, start, i);
      }
      continue;
    }

    if (ch === '(' || ch === ')' || ch === ',' || ch === '.') {
      i++;
      push(ch, ch, start, i);
      continue;
    }

    const operator = ['>=', '<=', '==', '!=', '&&', '||', '**', '+=', '-=', '*=', '/='].find(op => source.startsWith(op, i));
    if (operator) {
      i += operator.length;
      push('operator', operator, start, i);
      continue;
    }
    if ('+-*/%^!<>=?:'.includes(ch)) {
      i++;
      push(ch === '?' || ch === ':' ? ch : 'operator', ch, start, i);
      continue;
    }

    return { tokens, error: { message: `Unexpected character '${ch}' in math expression`, start: i } };
  }
  return { tokens, error: null };
}

function checkMathExpression(source) {
  const lexed = tokenizeMathExpression(source);
  if (lexed.error) return lexed.error;
  const tokens = lexed.tokens;
  if (!tokens.length) return { message: 'Empty math expression', start: 0 };
  let i = 0;
  let error = null;
  const precedence = new Map([
    ['||', 1], ['&&', 2], ['==', 3], ['!=', 3], ['<', 4], ['>', 4], ['<=', 4], ['>=', 4],
    ['+', 5], ['-', 5], ['*', 6], ['/', 6], ['%', 6], ['^', 7], ['**', 7]
  ]);
  const peek = () => tokens[i];
  const take = () => tokens[i++];
  const fail = (message, token = peek()) => {
    if (!error) error = { message, start: token ? token.start : source.length };
  };

  function parsePrimary() {
    const token = take();
    if (!token) { fail('Expected a value'); return; }
    if (token.type === 'number' || token.type === 'expansion' || token.type === 'reference') return;
    if (token.type === 'identifier') {
      // Function call: name(arg1, arg2, ...). Plain identifiers are valid variables/constants.
      if (peek()?.type === '(') {
        take();
        if (peek()?.type !== ')') {
          while (i < tokens.length) {
            parseExpression(0);
            if (error) return;
            if (peek()?.type === ',') { take(); continue; }
            break;
          }
        }
        if (peek()?.type !== ')') { fail("Expected ')' after function arguments"); return; }
        take();
      }
      parseMemberAccess();
      return;
    }
    if (token.type === '(') {
      parseExpression(0);
      if (peek()?.type !== ')') { fail("Expected ')' to close math expression"); return; }
      take();
      parseMemberAccess();
      return;
    }
    if (token.type === 'operator' && ['+', '-', '!'].includes(token.value)) {
      parsePrimary();
      return;
    }
    fail(`Unexpected token '${token.value}' in math expression`, token);
  }

  function parseMemberAccess() {
    while (peek()?.type === '.') {
      take();
      const member = take();
      if (!member || (member.type !== 'identifier' && member.type !== 'number')) {
        fail("Expected a member name after '.'", member || peek());
        return;
      }
    }
  }

  function parseExpression(minPrecedence = 0) {
    parsePrimary();
    if (error) return;
    while (i < tokens.length) {
      const token = peek();
      if (token.type === '?' && minPrecedence <= 0) {
        take();
        parseExpression(0);
        if (peek()?.type !== ':') { fail("Expected ':' in conditional expression"); return; }
        take();
        parseExpression(0);
        if (error) return;
        continue;
      }
      if (token.type !== 'operator' || !precedence.has(token.value)) break;
      const currentPrecedence = precedence.get(token.value);
      if (currentPrecedence < minPrecedence) break;
      take();
      parseExpression(currentPrecedence + (token.value === '^' || token.value === '**' ? 0 : 1));
      if (error) return;
    }
  }

  parseExpression(0);
  if (error) return error;
  if (i < tokens.length) return { message: `Expected an operator before '${tokens[i].value}'`, start: tokens[i].start };
  return null;
}

/**
 * Parse syntax.txt. Only non-indented lines declare commands; indented lines
 * containing parameter declarations continue the preceding signature. Other
 * indented documentation (effects/types enumerations) is intentionally ignored.
 */
function parseSyntaxDefinitions(source) {
  const definitions = new Map();
  let currentCommand = null;
  let currentModule = 'other';

  for (const rawLine of source.split(/\r?\n/)) {
    const trimmed = rawLine.trim();
    if (!trimmed) continue;

    // Section headings in syntax.txt classify commands. Keep this metadata
    // with each signature so editor features (including colors) always follow
    // the live file instead of maintaining a second hard-coded command list.
    if (trimmed.startsWith('#')) {
      const section = trimmed.match(/^#\s*([A-Za-z][A-Za-z0-9 _-]*?)\s+module\s+commands\s*$/i);
      if (section) currentModule = section[1].trim().toLowerCase();
      continue;
    }

    if (/^\s/.test(rawLine)) {
      if (currentCommand && /^(?:text|math|list|block|any)\s*\(/i.test(trimmed)) {
        definitions.get(currentCommand).params.push(...parseParamDeclarations(trimmed));
      }
      continue;
    }

    const commandMatch = trimmed.match(/^([A-Za-z_][A-Za-z0-9_.]*)(?:\s+|$)(.*)$/);
    if (!commandMatch) {
      currentCommand = null;
      continue;
    }

    const name = commandMatch[1];
    definitions.set(name, {
      name,
      module: currentModule,
      params: parseParamDeclarations(commandMatch[2] || '')
    });
    currentCommand = name;
  }

  return definitions;
}

function lineStarts(text) {
  const starts = [0];
  for (let i = 0; i < text.length; i++) {
    if (text.charCodeAt(i) === 10) starts.push(i + 1);
  }
  return starts;
}

function offsetToPosition(starts, offset) {
  let low = 0;
  let high = starts.length;
  while (low + 1 < high) {
    const mid = (low + high) >> 1;
    if (starts[mid] <= offset) low = mid;
    else high = mid;
  }
  return { line: low, character: Math.max(0, offset - starts[low]) };
}

function isHorizontalSpace(ch) {
  return ch === ' ' || ch === '\t' || ch === '\r';
}

function isWhitespace(ch) {
  return ch === ' ' || ch === '\t' || ch === '\r' || ch === '\n';
}

class NosParser {
  constructor(text, diagnostics) {
    this.text = text;
    this.length = text.length;
    this.pos = 0;
    this.diagnostics = diagnostics;
  }

  add(message, start, end, code = 'NOS100') {
    const safeStart = Math.max(0, Math.min(start, this.length));
    const safeEnd = Math.max(safeStart + 1, Math.min(end, this.length));
    this.diagnostics.push({ message, start: safeStart, end: safeEnd, code });
  }

  skipHorizontal() {
    while (this.pos < this.length && isHorizontalSpace(this.text[this.pos])) this.pos++;
  }

  skipWhitespaceAndComments() {
    while (this.pos < this.length) {
      if (isWhitespace(this.text[this.pos])) {
        this.pos++;
        continue;
      }
      if (this.text[this.pos] === '#') {
        while (this.pos < this.length && this.text[this.pos] !== '\n') this.pos++;
        continue;
      }
      break;
    }
  }

  atLineEnd() {
    let p = this.pos;
    while (p < this.length && isHorizontalSpace(this.text[p])) p++;
    return p >= this.length || this.text[p] === '\n' || this.text[p] === '#';
  }

  parseString(expectedType = 'text') {
    const start = this.pos;
    if (this.text[this.pos] !== "'") {
      if (this.text[this.pos] === '"') {
        this.add(`Double-quoted strings are not supported; use single quotes for ${expectedType} arguments`, start, start + 1, 'NOS201');
        this.pos++;
        while (this.pos < this.length && this.text[this.pos] !== '"' && this.text[this.pos] !== '\n') this.pos++;
        if (this.text[this.pos] === '"') this.pos++;
        return { start, end: this.pos, ok: false };
      }
      this.add(`Expected a single-quoted text value for ${expectedType} argument`, start, start + 1, 'NOS202');
      return { start, end: start, ok: false };
    }

    this.pos++;
    while (this.pos < this.length) {
      const ch = this.text[this.pos];
      if (ch === "'") {
        this.pos++;
        return { start, end: this.pos, ok: true };
      }
      // NOS strings have no escaping: a backslash does not protect a quote.
      this.pos++;
    }

    this.add('Unterminated text string; expected closing single quote', start, this.length, 'NOS203');
    return { start, end: this.pos, ok: false };
  }

  parseExpansion() {
    const start = this.pos;
    if (this.text[this.pos] !== '*') return false;
    this.pos++;
    const nameStart = this.pos;
    while (this.pos < this.length && /[A-Za-z0-9_.$]/.test(this.text[this.pos])) this.pos++;
    if (this.pos === nameStart) {
      this.add("Expected a variable name after '*'", start, this.pos, 'NOS204');
      return true;
    }
    return true;
  }

  parseTextValue(typeName) {
    this.skipHorizontal();
    if (this.text[this.pos] === '*') {
      this.parseExpansion();
      return;
    }
    this.parseString(typeName);
  }

  /** Read one math expression up to a NOS delimiter at parenthesis depth zero. */
  parseMathExpression(context = 'argument') {
    this.skipHorizontal();
    const start = this.pos;
    let parenDepth = 0;

    while (this.pos < this.length) {
      const ch = this.text[this.pos];
      if (ch === "'") {
        // Quotes are never a math literal. Stop here so the caller can recover
        // and parse a following text parameter if the semicolon is missing.
        break;
      }
      if (ch === '#') break;
      if (ch === '(') {
        parenDepth++;
        this.pos++;
        continue;
      }
      if (ch === ')') {
        if (parenDepth > 0) parenDepth--;
        this.pos++;
        continue;
      }
      if (parenDepth === 0 && (ch === '\n' || ch === ';' || ch === ']' || ch === '[' || ch === '{')) break;
      this.pos++;
    }

    const rawValue = this.text.slice(start, this.pos);
    const leading = rawValue.length - rawValue.trimStart().length;
    const value = rawValue.trim();
    if (!value) {
      this.add(`Expected a math expression for ${context}`, start, Math.min(start + 1, this.length), 'NOS205');
    } else {
      const mathError = checkMathExpression(value);
      if (mathError) {
        const errorStart = start + leading + mathError.start;
        this.add(`Invalid math expression: ${mathError.message}`, errorStart, Math.min(errorStart + 1, this.length), 'NOS219');
      }
    }
    return { start, end: this.pos, value, delimiter: this.text[this.pos] || '' };
  }

  parseList(context = 'list') {
    this.skipHorizontal();
    const start = this.pos;
    if (this.text[this.pos] !== '[') {
      this.add(`Expected '[' to begin ${context}`, start, start + 1, 'NOS206');
      return false;
    }
    this.pos++;
    this.skipWhitespaceAndComments();
    if (this.text[this.pos] === ']') {
      this.pos++;
      return true;
    }

    let expectingValue = true;
    while (this.pos < this.length) {
      this.skipWhitespaceAndComments();
      if (this.text[this.pos] === ']') {
        if (expectingValue) this.add('Empty list item; remove the trailing separator', Math.max(start, this.pos - 1), this.pos, 'NOS207');
        this.pos++;
        return true;
      }
      if (this.text[this.pos] === ';') {
        this.add('Empty list item; values must be separated by a single semicolon', this.pos, this.pos + 1, 'NOS207');
        this.pos++;
        expectingValue = true;
        continue;
      }

      const before = this.pos;
      this.parseAnyValue('list item');
      if (this.pos === before) {
        this.add('Could not parse list item', this.pos, this.pos + 1, 'NOS208');
        this.pos++;
      }
      expectingValue = false;
      this.skipWhitespaceAndComments();

      if (this.text[this.pos] === ';') {
        this.pos++;
        expectingValue = true;
        this.skipWhitespaceAndComments();
        if (this.text[this.pos] === ']') {
          this.add('Trailing semicolon creates an empty list item', this.pos - 1, this.pos, 'NOS207');
          this.pos++;
          return true;
        }
        continue;
      }
      if (this.text[this.pos] === ']') {
        this.pos++;
        return true;
      }
      if (this.pos >= this.length) break;

      this.add("Expected ';' or ']' after list value", this.pos, this.pos + 1, 'NOS209');
      // Recover at the next separator or the current list's closing bracket.
      while (this.pos < this.length && this.text[this.pos] !== ';' && this.text[this.pos] !== ']') {
        if (this.text[this.pos] === "'") {
          this.parseString('list item');
        } else {
          this.pos++;
        }
      }
    }

    this.add(`Unclosed ${context}; expected ']'`, start, start + 1, 'NOS210');
    return false;
  }

  parseAnyValue(context = 'value') {
    this.skipWhitespaceAndComments();
    const ch = this.text[this.pos];
    if (ch === "'") {
      this.parseString(context);
      return;
    }
    if (ch === '[') {
      this.parseList(context);
      return;
    }
    if (ch === '*') {
      this.parseExpansion();
      return;
    }
    if (ch === '"') {
      this.parseString(context);
      return;
    }
    this.parseMathExpression(context);
  }

  parseBlock(context = 'code block') {
    this.skipHorizontal();
    const start = this.pos;
    if (this.text[this.pos] !== '{') {
      this.add(`Expected '{' to begin ${context}`, start, start + 1, 'NOS211');
      return false;
    }

    let depth = 0;
    let inString = false;
    let inComment = false;
    for (let i = this.pos; i < this.length; i++) {
      const ch = this.text[i];
      if (inComment) {
        if (ch === '\n') inComment = false;
        continue;
      }
      if (inString) {
        if (ch === "'") inString = false;
        continue;
      }
      if (ch === '#') {
        inComment = true;
        continue;
      }
      if (ch === "'") {
        inString = true;
        continue;
      }
      if (ch === '{') depth++;
      else if (ch === '}') {
        depth--;
        if (depth === 0) {
          this.pos = i + 1;
          return true;
        }
      }
    }

    this.pos = this.length;
    this.add(`Unclosed ${context}; expected '}'`, start, start + 1, 'NOS212');
    return false;
  }

  parseParameter(param, paramIndex, params, commandName, commandRange) {
    this.skipHorizontal();
    if (this.atLineEnd()) {
      this.add(`Missing ${param.type} argument '${param.name}'`, commandRange.start, commandRange.end, 'NOS213');
      return false;
    }

    switch (param.type) {
      case 'text':
        this.parseTextValue(param.name || 'text');
        break;
      case 'list':
        if (this.text[this.pos] === '*') this.parseExpansion();
        else this.parseList(`list argument '${param.name}'`);
        break;
      case 'block':
        if (this.text[this.pos] === '*') this.parseExpansion();
        else this.parseBlock(`block argument '${param.name}'`);
        break;
      case 'any':
        this.parseAnyValue(`argument '${param.name}'`);
        break;
      case 'math': {
        const result = this.parseMathExpression(`argument '${param.name}'`);
        const hasFollowingParam = paramIndex < params.length - 1;
        if (this.text[this.pos] === ';') {
          this.pos++;
        } else if (hasFollowingParam && this.text[this.pos] !== ']' && this.text[this.pos] !== '{') {
          this.add(`Expected ';' after math argument '${param.name}'`, result.start, Math.max(result.end, result.start + 1), 'NOS214');
        }
        break;
      }
      default:
        this.add(`Unknown parameter type '${param.type}' in syntax.txt`, commandRange.start, commandRange.end, 'NOS215');
        return false;
    }

    return true;
  }

  parseCommand(lineStart, commandMatch, definition) {
    const commandName = commandMatch[1];
    const commandStart = lineStart + commandMatch.index + commandMatch[0].indexOf(commandName);
    const commandRange = { start: commandStart, end: commandStart + commandName.length };
    this.pos = lineStart + commandMatch.index + commandMatch[0].length;

    for (let i = 0; i < definition.params.length; i++) {
      this.skipHorizontal();
      if (this.pos >= this.length || this.text[this.pos] === '\n' || this.text[this.pos] === '#') {
        this.add(`Missing ${definition.params[i].type} argument '${definition.params[i].name}'`, commandRange.start, commandRange.end, 'NOS213');
        break;
      }
      const before = this.pos;
      this.parseParameter(definition.params[i], i, definition.params, commandName, commandRange);
      if (this.pos <= before) {
        this.add(`Could not parse argument '${definition.params[i].name}'`, before, before + 1, 'NOS216');
        this.pos = before + 1;
      }

      // Values other than math arguments are whitespace-separated. Math
      // arguments consume their semicolon in parseParameter when required.
      if (definition.params[i].type !== 'math' && i < definition.params.length - 1) {
        if (this.pos < this.length && !isWhitespace(this.text[this.pos]) && this.text[this.pos] !== '#') {
          this.add(`Expected whitespace before argument '${definition.params[i + 1].name}'`, this.pos, this.pos + 1, 'NOS217');
        }
      }
    }

    this.skipHorizontal();
    if (this.pos < this.length && this.text[this.pos] !== '\n' && this.text[this.pos] !== '#' && this.text[this.pos] !== '}' && this.text[this.pos] !== ']') {
      this.add(`Unexpected extra content after '${commandName}' arguments`, this.pos, this.lineEnd(this.pos), 'NOS218');
    }
  }

  lineEnd(position) {
    let p = position;
    while (p < this.length && this.text[p] !== '\n') p++;
    return Math.max(p, position + 1);
  }
}

/** Return true for lines whose first non-whitespace character is inside a multiline string. */
function getLineStringStates(text) {
  const states = [];
  let inString = false;
  let inComment = false;
  let line = 0;
  states[0] = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '\n') {
      line++;
      states[line] = inString;
      inComment = false;
      continue;
    }
    if (inComment) continue;
    if (inString) {
      if (ch === "'") inString = false;
      continue;
    }
    if (ch === '#') inComment = true;
    else if (ch === "'") inString = true;
  }
  return states;
}

function scanStructure(text, diagnostics) {
  const stack = [];
  let quoteStart = -1;
  let inComment = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inComment) {
      if (ch === '\n') inComment = false;
      continue;
    }
    if (quoteStart !== -1) {
      if (ch === "'") quoteStart = -1;
      continue;
    }
    if (ch === '#') {
      inComment = true;
      continue;
    }
    if (ch === "'") {
      quoteStart = i;
      continue;
    }
    if (ch === '(' || ch === '[' || ch === '{') {
      stack.push({ expected: ch === '(' ? ')' : ch === '[' ? ']' : '}', start: i, open: ch });
      continue;
    }
    if (ch === ')' || ch === ']' || ch === '}') {
      const top = stack[stack.length - 1];
      if (!top || top.expected !== ch) {
        diagnostics.push({ message: `Unexpected closing '${ch}'`, start: i, end: i + 1, code: 'NOS003' });
      } else {
        stack.pop();
      }
    }
  }

  if (quoteStart !== -1) {
    diagnostics.push({ message: 'Unterminated text string; NOS strings close only with a single quote', start: quoteStart, end: Math.min(text.length, quoteStart + 1), code: 'NOS002' });
  }
  for (const item of stack) {
    diagnostics.push({ message: `Missing closing '${item.expected}' for '${item.open}'`, start: item.start, end: item.start + 1, code: 'NOS004' });
  }
}

function validateDocument(text, definitions) {
  const diagnostics = [];
  scanStructure(text, diagnostics);
  const starts = lineStarts(text);
  const lines = text.split('\n');
  const stringStates = getLineStringStates(text);
  const parser = new NosParser(text, diagnostics);

  let offset = 0;
  for (let lineNumber = 0; lineNumber < lines.length; lineNumber++) {
    const line = lines[lineNumber];
    if (!stringStates[lineNumber]) {
      const trimmedStart = line.search(/\S/);
      if (trimmedStart !== -1 && line[trimmedStart] !== '#' && line[trimmedStart] !== '@') {
        const code = line.slice(trimmedStart);
        const match = code.match(/^([A-Za-z_][A-Za-z0-9_.]*)\b/);
        if (match) {
          const definition = definitions.get(match[1]);
          if (definition) parser.parseCommand(offset + trimmedStart, match, definition);
        }
      }
    }
    offset += line.length + 1;
  }

  // Remove exact duplicate diagnostics (e.g. an unterminated string can be
  // detected both by the structural scan and an argument-specific parse).
  const unique = new Map();
  for (const item of diagnostics) {
    const key = `${item.code}:${item.start}:${item.end}:${item.message}`;
    unique.set(key, item);
  }

  return [...unique.values()].map(item => {
    const start = offsetToPosition(starts, item.start);
    const end = offsetToPosition(starts, item.end);
    return { ...item, range: { start, end } };
  });
}

function findCommentStart(line) {
  let inString = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inString) {
      if (ch === "'") inString = false;
    } else if (ch === "'") {
      inString = true;
    } else if (ch === '#') {
      return i;
    }
  }
  return line.length;
}

module.exports = {
  parseSyntaxDefinitions,
  parseParamDeclarations,
  checkMathExpression,
  validateDocument,
  findCommentStart,
  NosParser
};
