'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { parseSyntaxDefinitions, validateDocument, checkMathExpression } = require('../syntax');

const syntax = fs.readFileSync(path.join(__dirname, '..', 'syntax.txt'), 'utf8');
const defs = parseSyntaxDefinitions(syntax);
assert.ok(defs.size > 70, `Expected many command definitions, got ${defs.size}`);
assert.equal(defs.get('World.cloneBlocks').params.length, 11, 'Multiline signature continuation should be parsed');
assert.equal(defs.get('setGlobal').module, 'op', 'Op module heading should be retained as command metadata');
assert.equal(defs.get('Shiver.music').module, 'shiver', 'Other module headings should be retained as command metadata');
assert.equal(defs.get('Shiver.spawnTrigger').params.at(-1).type, 'block');
assert.equal(defs.has('effects'), false, 'Indented effects documentation is not a command');
assert.equal(defs.has('types'), false, 'Indented types documentation is not a command');
assert.equal(defs.has('invisibility'), false, 'Enum values are not commands');
const changedCatalog = parseSyntaxDefinitions('NewModule.newCommand text(value) any(payload)');
assert.deepEqual([...changedCatalog.keys()], ['NewModule.newCommand'], 'Command catalogue must be replaced by the current syntax.txt, not merged with old commands');


// var()/global() contents are opaque NOS variable paths, not math arguments.
for (const expression of [
  'var(arg.1)',
  'var(any text / path - 1)',
  'global(WAVE)',
  'global(var(target).ifFalled)',
  'var(arg.1) + 2',
  'max(var(arg.1), global(WAVE))'
]) {
  assert.equal(checkMathExpression(expression), null, `NOS variable reference should be accepted: ${expression}`);
}
const opaqueReferences = validateDocument(
  "Entity.tp 'var(pl)' var(arg.1); var(arg.2); var(arg.3); 0; 90;",
  defs
);
assert.deepEqual(opaqueReferences, [], `NOS var() references should not be parsed as math calls: ${opaqueReferences.map(d => d.message).join('; ')}`);

const good = `
Shiver.title 30; 120; 0; 'title' 'subtitle'
World.cloneBlocks 1; 2; 3; 4; 5; 6; 7; 8; 9; 'false' 'false'
Shiver.spawnTrigger 'id' 'team' 0; 1; 2; 3; 4; 5; 6; {
  message 'inside'
}
Entity.effect 'var(ply)' 'blindness' -1; 0; 0; 0; 1;
Shiver.spawnWave 'wave' 'global(WAVE)' global(WAVE) >= var(amount)
Shiver.showActionbar 'wait' global(LORE_SPEED); 'global(LORE_PREFIX)' 'Hello'
Shiver.spawnClones 218.5; 42; -72.5; 'tasks' 2.5
list.add 'items' *arg.0
`;
const goodDiagnostics = validateDocument(good, defs);
assert.deepEqual(goodDiagnostics, [], `Expected no diagnostics for valid sample, got: ${goodDiagnostics.map(d => d.message).join('; ')}`);

const bad = `
Shiver.title 30 120; 0; 'title' 'subtitle'
Shiver.spawnTrigger 'id' 'team' 0; 1; 2; 3; 4; 5; 6;
Shiver.clearMap extra
`;
const badDiagnostics = validateDocument(bad, defs);
assert.ok(badDiagnostics.some(d => d.code === 'NOS219'), 'Should detect invalid math expression / missing operator');
assert.ok(badDiagnostics.some(d => d.code === 'NOS214'), 'Should detect a missing semicolon between math arguments');
assert.ok(badDiagnostics.some(d => d.code === 'NOS213'), 'Should detect a missing block argument');
assert.ok(badDiagnostics.some(d => d.code === 'NOS218'), 'Should detect extra arguments');

const custom = parseSyntaxDefinitions(`say text(message)\nlistTest list(values)\nanyTest any(value)\nmathTest math(expr)\nmathList math(first) list(second)\nmathBlock math(first) block(code)\nblockTest block(code)`);
const nested = validateDocument(`say 'first line\nsecond line'\nlistTest ['outer'; [1; 'sub']; *arg.0; var(x) + 2]\nanyTest 'text'\nanyTest [1; 'nested']\nmathTest max(1, var(x)) / 2\nmathTest *arg.0 + 2\nmathList 12; [1; 2]\nmathBlock 12 { say 'inside' }\nblockTest *codeBlock`, custom);
assert.deepEqual(nested, [], `Multiline text, nested lists, any dispatch and math should pass: ${nested.map(d => d.message).join('; ')}`);

const invalidList = validateDocument(`listTest [1;; 2]\nlistTest ['x';]\nlistTest ['a' 'b']`, custom);
assert.ok(invalidList.some(d => d.code === 'NOS207'), 'Should detect empty list values');
assert.ok(invalidList.some(d => d.code === 'NOS209'), 'Should detect missing list separators');

const separatorRules = validateDocument(`mathList 1 [2]\nmathBlock 1 { say 'ok' }`, custom);
assert.ok(separatorRules.some(d => d.code === 'NOS214'), 'A semicolon is required before a list following a math parameter');
assert.ok(!separatorRules.some(d => d.code === 'NOS214' && d.range.start.line === 1), 'Math immediately before a block may omit the separator');

const invalidText = validateDocument(`say "double quotes"`, custom);
assert.ok(invalidText.some(d => d.code === 'NOS201'), 'Text arguments must reject double quotes');

const structure = validateDocument("if (var(x)) {\nsay 'unclosed\n", custom);
assert.ok(structure.some(d => d.code === 'NOS002'));
assert.ok(structure.some(d => d.code === 'NOS004'));

assert.equal(checkMathExpression('204 * (var(time) - 10) / (global(PREPARE_TIME) - 10)'), null);
assert.equal(checkMathExpression('pow(var(t1), 3)'), null);
assert.ok(checkMathExpression('30 120'), 'Adjacent values without an operator should be invalid');
assert.ok(checkMathExpression('1 +'), 'Trailing operator should be invalid');

console.log(`Parser tests passed. Parsed ${defs.size} NOS commands.`);

const { collectHighlights } = require('../highlight');
const highlightSpans = collectHighlights(
  "@propPlace\n    Shiver.music 'theme' 1; 1;\nEntity.tp 'var(pl)' 1; 2; 3; 0; 90;\n# Shiver.music should not be highlighted\nmessage 'Shiver.music should stay text'",
  defs
);
assert.deepEqual(highlightSpans, [
  { line: 0, start: 0, length: 10, type: 'label' },
  { line: 1, start: 4, length: 'Shiver.music'.length, type: 'command' },
  { line: 2, start: 0, length: 'Entity.tp'.length, type: 'command' },
  { line: 4, start: 0, length: 'message'.length, type: 'opCommand' }
], 'Labels and commands should be detected, excluding comments and string contents');

const continuedStringHighlights = collectHighlights(
  "message 'first line\nShiver.music is only text here\n@notALabel either'\nShiver.music 'real command'\n@realLabel",
  defs
);
assert.deepEqual(continuedStringHighlights, [
  { line: 0, start: 0, length: 'message'.length, type: 'opCommand' },
  { line: 3, start: 0, length: 'Shiver.music'.length, type: 'command' },
  { line: 4, start: 0, length: '@realLabel'.length, type: 'label' }
], 'Command-like lines inside multiline strings must not be highlighted');

const reclassifiedCatalog = parseSyntaxDefinitions('# Op module commands\nalpha text(value)\n# World module commands\nWorld.time math(time)');
const reclassifiedHighlights = collectHighlights(`alpha\nWorld.time 10;`, reclassifiedCatalog);
assert.equal(reclassifiedHighlights[0].type, 'opCommand');
assert.equal(reclassifiedHighlights[1].type, 'command');
