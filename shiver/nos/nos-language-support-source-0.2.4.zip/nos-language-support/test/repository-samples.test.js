'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { parseSyntaxDefinitions, validateDocument } = require('../syntax');
const syntax = fs.readFileSync(path.join(__dirname, '..', 'syntax.txt'), 'utf8');
const defs = parseSyntaxDefinitions(syntax);

const sample = `
# Extracts based on Shiver map scripts
Shiver.getPlayers 'players'
forEach '*' 'ply' 'players' {
    Shiver.resetPlayer 'var(ply)'
    Entity.effect 'var(ply)' 'blindness' -1; 0; 0; 0; 1;
    Player.gamemode 'var(ply)' 'spectator'
}
Shiver.title 30; 120; 0; 'global(MAP_TITLE)' ' '
World.setBlocks 1; 'light' 218; 46; -75; 218; 46; -75;
Shiver.spawnTrigger 'waterHurt' 'global(TEAM_SURVIVORS)' 3; 119; 0; -112; 267; 38; 64; {
    if !global(var(target).ifFalled) {
        setGlobal 'var(target).ifFalled' 1
    }
}
parallel '*' [] {
    World.sound 'shiver:ambience.map1heli' 16; 1.1; 242.59; 53.11; -51.84;
}
String.sub 1; len(color); 'var(color)' 'color'
Shiver.spawnWave 'wave' 'global(WAVE)' global(WAVE) >= var(amount)
Shiver.addPoint 'var(ply)' var(bonus); 0;
Shiver.showActionbar 'wait' global(LORE_SPEED); 'global(LORE_PREFIX)' 'Hello'
Shiver.spawnClones 218.5; 42; -72.5; 'tasks' 2.5
`;
const diagnostics = validateDocument(sample, defs);
assert.deepEqual(diagnostics, [], `Unexpected diagnostics: ${diagnostics.map(d => `line ${d.range.start.line + 1}: ${d.message}`).join('; ')}`);
console.log('Repository sample syntax checks passed.');
